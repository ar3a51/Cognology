﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Cognology.Model
{
    public class Bookings
    {
        public string PassengerName { set; get; }
        public DateTime Date { set; get; }
        public string ArrivalCity { set; get; }
        public string DepartureCity { set; get; }
        public string FlightNumber { set; get; }
    }
}

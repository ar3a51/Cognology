﻿using System;

namespace Cognology.Model
{
    public class Flight
    {
        public string FlightNo { set; get; }
        public DateTime StartTime { set; get; }
        public DateTime EndTime { set; get; }
        public int PassengerCapacity { set; get; }
        public string DepartureCity { set; get; }
        public string ArrivalCity { set; get; }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Text;
using Autofac;

namespace Cognology.Repository
{
    public class DependencyModule: Module
    {
        protected override void Load(ContainerBuilder builder)
        {
            builder.Register(b => new FlightBookingRepository()).As<IFlightRepository>().SingleInstance();
        }
    }
}

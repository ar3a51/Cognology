﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;

using Cognology.Model;

namespace Cognology.Repository
{
    public class FlightBookingRepository : IFlightRepository
    {
        private List<Flight> _flightList;
        private List<Bookings> _bookingList;

        public FlightBookingRepository()
        {
            _flightList = new List<Flight>();
            _bookingList = new List<Bookings>();

            PrefillFlightBookingData();

        }

        private void PrefillFlightBookingData()
        {
            _flightList.Add(new Flight {
                FlightNo = "A111",
                DepartureCity = "Melbourne, Australia",
                ArrivalCity = "Sydney, Australia",
                StartTime = new DateTime(2018, 5, 20, 17, 0, 0),
                EndTime = new DateTime(2018, 5, 20, 20, 0, 0),
                PassengerCapacity = 300
            });

            _flightList.Add(new Flight
            {
                FlightNo = "A122",
                DepartureCity = "Melbourne, Australia",
                ArrivalCity = "Perth, Australia",
                StartTime = new DateTime(2018, 5, 20, 23, 0, 0),
                EndTime = new DateTime(2018, 5, 20, 01, 0, 0),
                PassengerCapacity = 400
            });

            _flightList.Add(new Flight
            {
                FlightNo = "A133",
                DepartureCity = "Melbourne, Australia",
                ArrivalCity = "Darwin, Australia",
                StartTime = new DateTime(2018, 5, 25, 5, 0, 0),
                EndTime = new DateTime(2018, 5, 25, 10, 0, 0),
                PassengerCapacity = 300
            });

            _bookingList.Add(new Bookings {
                ArrivalCity = "Sydney, Australia",
                Date = new DateTime(2018, 5, 20, 8, 0, 0),
                DepartureCity = "Melbourne, Australia",
                FlightNumber = "A111",
                PassengerName = "John Smith"
            });

            _bookingList.Add(new Bookings
            {
                ArrivalCity = "Perth, Australia",
                Date = new DateTime(2018, 5, 20, 10, 0, 0),
                DepartureCity = "Melbourne, Australia",
                FlightNumber = "A122",
                PassengerName = "Jane Smith"
            });

            _bookingList.Add(new Bookings
            {
                ArrivalCity = "Darwin, Australia",
                Date = new DateTime(2018, 5, 20, 8, 0, 0),
                DepartureCity = "Melbourne, Australia",
                FlightNumber = "A111",
                PassengerName = "John Smith"
            });
        }

        public void AddFlightInformation(Flight flightInformation)
        {
            _flightList.Add(flightInformation);
        }

        public IEnumerable<Flight> GetAllFlights()
        {
            return _flightList;
        }

        public IEnumerable<Flight> GetFlightAvailability(DateTime startDate, DateTime endDate, int noOfPassengers)
        {
            return _flightList.Where(f => f.StartTime > startDate && f.EndTime < endDate && f.PassengerCapacity > noOfPassengers).ToList();
        }

        public void MakeBooking(Bookings bookingDetails)
        {
            _bookingList.Add(bookingDetails);
        }

        public IEnumerable<Bookings> GetBookingByPassengerName(string passengerName)
        {
            return _bookingList.Where(b => b.PassengerName.ToLower().Contains(passengerName.ToLower())).ToList();
        }

        public IEnumerable<Bookings> GetBookingByDate(DateTime bookingDate)
        {
            return _bookingList.Where(b => b.Date > bookingDate && bookingDate < b.Date.AddDays(1)).ToList();
        }

        public IEnumerable<Bookings> GetBookingByArrivalCity(string arrivalCity)
        {
            return _bookingList.Where(b => b.ArrivalCity.ToLower().Contains(arrivalCity.ToLower())).ToList();
        }

        public IEnumerable<Bookings> GetBookingByDepartureCity(string departureCity)
        {
            return _bookingList.Where(b => b.DepartureCity.ToLower().Contains(departureCity.ToLower())).ToList();
        }

        public IEnumerable<Bookings> GetBookingByFlightNumber(string flightNumber)
        {
            return _bookingList.Where(b => b.FlightNumber.ToLower().Contains(flightNumber.ToLower())).ToList();
        }
    }
}

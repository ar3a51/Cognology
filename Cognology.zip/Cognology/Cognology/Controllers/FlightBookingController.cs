﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Cognology.ModelView;
using Cognology.Model;
using Cognology.Service;

namespace Cognology.Controllers
{
    [Route("api/[controller]")]
    public class FlightBookingController : Controller
    {
        private IFlightBookingService _flightBookingService;

        public FlightBookingController(IFlightBookingService flightBookingService)
        {
            _flightBookingService = flightBookingService;

        }

        /// <summary>
        /// Return all flights information
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        public IActionResult GetAllFlights()
        {
            try
            {
                return Ok(_flightBookingService.GetAllFlights());
            }
            catch (Exception ex)
            {
                return StatusCode(500, ex.Message);
            }
        }

        /// <summary>
        ///     Retrieve booking based on the arrival city
        /// </summary>
        /// <param name="arrivalCity"></param>
        /// <returns></returns>
        [HttpGet("booking/arrival/{arrivalCity}")]
        public IActionResult GetBookingByArrivalCity(string arrivalCity)
        {
            try
            {
                return Ok(_flightBookingService.GetBookingByArrivalCity(arrivalCity));
            }
            catch (Exception ex)
            {
                return StatusCode(500, ex.Message);
            }
        }

        /// <summary>
        ///     Retrieve booking by arrival date
        /// </summary>
        /// <remarks>
        ///     date format: (yyyy-mm-dd)
        ///     sample data pass: 2018-05-20 
        /// </remarks>
        /// <param name="date"></param>
        /// <returns></returns>
        [HttpGet("booking/arrivaldate/{date}")]
        public IActionResult GetBookingByArrivalDate(DateTime date)
        {
            try
            {
                return Ok(_flightBookingService.GetBookingByDate(date));
            }
            catch (Exception ex)
            {
                return StatusCode(500, ex.Message);
            }
        }


        /// <summary>
        ///     Retrieve booking based on departure city
        /// </summary>
        /// <remarks>
        ///     Sample data: Melbourne
        /// </remarks>
        /// <param name="departureCity"></param>
        /// <returns></returns>
        [HttpGet("booking/departurecity/{departureCity}")]
        public IActionResult GetBookingByDepartureCity(string departureCity)
        {
            try
            {
                return Ok(_flightBookingService.GetBookingByDepartureCity(departureCity));
            }
            catch (Exception ex)
            {
                return StatusCode(500, ex.Message);
            }
        }

        /// <summary>
        ///     Retrieve booking by flight number
        /// </summary>
        /// <remarks>
        ///   Sample data:
        ///     - A111
        ///     - A122
        /// </remarks>
        /// <param name="flightNumber"></param>
        /// <returns></returns>
        [HttpGet("booking/flightnumber/{flightNumber}")]
        public IActionResult GetBookingByFlightNumber(string flightNumber)
        {
            try
            {
                return Ok(_flightBookingService.GetBookingByFlightNumber(flightNumber));
            }
            catch (Exception ex)
            {
                return StatusCode(500, ex.Message);
            }
        }

        /// <summary>
        ///     Retrieve booking by passenger name
        /// </summary>
        /// <remarks>
        ///     sample data:
        ///     - John
        ///     - Jane
        ///     
        /// </remarks>
        /// <param name="passengerName"></param>
        /// <returns></returns>
        [HttpGet("booking/passengername/{passengerName}")]
        public IActionResult GetBookingByPassangerName(string passengerName)
        {
            try
            {
                return Ok(_flightBookingService.GetBookingByPassengerName(passengerName));
            }
            catch (Exception ex)
            {
                return StatusCode(500, ex.Message);
            }
        }


        /// <summary>
        ///  Search flight availability
        /// </summary>
        /// <param name="searchFlightAvailabilityModel"></param>
        /// <returns></returns>
        [HttpPost("booking")]
        public IActionResult GetFlightAvailability([FromBody] SearchFlightAvailabilityModel searchFlightAvailabilityModel)
        {
            try
            {
                return Ok(_flightBookingService.GetFlightAvailability(
                    searchFlightAvailabilityModel.StartDate,
                    searchFlightAvailabilityModel.EndDate,
                    searchFlightAvailabilityModel.NoOfPassengers)
                );
            }
            catch (Exception ex)
            {
                return StatusCode(500, ex.Message);
            }
        }

        /// <summary>
        ///     Create booking based on passenger name, date, Arrival city, departure city, flight number
        /// </summary>
        /// <remarks>
        ///     Query the /api/flightBooking to get the list of all flight
        ///     
        ///     if flight number can't be found in the list of flights, it will create new entry under list of all flights.
        ///     start time is now and end time will always be 5 hours from start time.
        ///     
        ///     date format: (yyyy-mm-dd)
        /// </remarks>
        /// <param name="bookings"></param>
        [HttpPost("makebookings")]
        public IActionResult MakeBooking([FromBody] Bookings bookings)
        {
            try
            {
                _flightBookingService.MakeBooking(bookings);
                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(500, ex.Message);
            }
        }
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Cognology.ModelView
{
    public class SearchFlightAvailabilityModel
    {
        public DateTime StartDate { set; get; }
        public DateTime EndDate { set; get; }
        public int NoOfPassengers { set; get; }
    }
}

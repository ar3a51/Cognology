﻿using System;
using System.Collections.Generic;
using System.Text;
using Autofac;
using Cognology.Repository;

namespace Cognology.Service
{
    public class DependencyModule : Module
    {
        protected override void Load(ContainerBuilder builder)
        {
            builder.Register(b => new FlightBookingService(b.Resolve<IFlightRepository>())).As<IFlightBookingService>().InstancePerLifetimeScope();
        }
    }
}

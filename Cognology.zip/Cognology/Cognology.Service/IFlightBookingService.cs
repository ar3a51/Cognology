﻿using System;
using System.Collections.Generic;
using System.Text;
using Cognology.Model;


namespace Cognology.Service
{
   public interface IFlightBookingService
    {
        IEnumerable<Flight> GetAllFlights();
        IEnumerable<Flight> GetFlightAvailability(DateTime startDate, DateTime endDate, int noOfPassengers);
        void MakeBooking(Bookings bookingDetails);
        IEnumerable<Bookings> GetBookingByPassengerName(string passengerName);
        IEnumerable<Bookings> GetBookingByDate(DateTime bookingDate);
        IEnumerable<Bookings> GetBookingByArrivalCity(string arrivalCity);
        IEnumerable<Bookings> GetBookingByDepartureCity(string departureCity);
        IEnumerable<Bookings> GetBookingByFlightNumber(string flightNumber);

    }
}

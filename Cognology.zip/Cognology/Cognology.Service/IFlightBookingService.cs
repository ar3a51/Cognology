﻿using System;
using System.Collections.Generic;
using System.Text;
using Cognology.Model;


namespace Cognology.Service
{
   public interface IFlightBookingService
    {
        /// <summary>
        ///  Get all the available flights
        /// </summary>
        /// <returns></returns>
        IEnumerable<Flight> GetAllFlights();

        /// <summary>
        /// Get flight availability by start date, end date and no of passengers
        /// </summary>
        /// <param name="startDate"></param>
        /// <param name="endDate"></param>
        /// <param name="noOfPassengers"></param>
        /// <returns></returns>
        IEnumerable<Flight> GetFlightAvailability(DateTime startDate, DateTime endDate, int noOfPassengers);

        /// <summary>
        ///  Make booking
        /// </summary>
        /// <param name="bookingDetails"></param>
        void MakeBooking(Bookings bookingDetails);

        /// <summary>
        ///  Get booking by passenger name
        /// </summary>
        /// <param name="passengerName"></param>
        /// <returns></returns>
        IEnumerable<Bookings> GetBookingByPassengerName(string passengerName);

        /// <summary>
        ///  Get booking by date
        /// </summary>
        /// <param name="bookingDate"></param>
        /// <returns></returns>
        IEnumerable<Bookings> GetBookingByDate(DateTime bookingDate);

        /// <summary>
        ///  Get booking by arrival City
        /// </summary>
        /// <param name="arrivalCity"></param>
        /// <returns></returns>
        IEnumerable<Bookings> GetBookingByArrivalCity(string arrivalCity);

        /// <summary>
        ///  Get booking by departure city
        /// </summary>
        /// <param name="departureCity"></param>
        /// <returns></returns>
        IEnumerable<Bookings> GetBookingByDepartureCity(string departureCity);

        /// <summary>
        /// Get booking by flight number
        /// </summary>
        /// <param name="flightNumber"></param>
        /// <returns></returns>
        IEnumerable<Bookings> GetBookingByFlightNumber(string flightNumber);

    }
}

﻿using System;
using System.Linq;
using System.Collections.Generic;
using Cognology.Model;
using Cognology.Repository;

namespace Cognology.Service
{
    public class FlightBookingService : IFlightBookingService
    {
        private IFlightRepository _flightRepository;

        public FlightBookingService(IFlightRepository flightRepository)
        {
            _flightRepository = flightRepository;
        }

        public IEnumerable<Flight> GetAllFlights()
        {
            return _flightRepository.GetAllFlights();
        }

        public IEnumerable<Bookings> GetBookingByArrivalCity(string arrivalCity)
        {
            if (string.IsNullOrEmpty(arrivalCity))
                throw new ArgumentNullException(String.Format("arrivalCity can't be empty - {0}", "FlightBookingService"));

            return _flightRepository.GetBookingByArrivalCity(arrivalCity);
        }

        public IEnumerable<Bookings> GetBookingByDate(DateTime bookingDate)
        {
            if (bookingDate == null)
                throw new ArgumentNullException(String.Format("bookingDate can't be empty- {0}", "FlightBookingService"));


            return _flightRepository.GetBookingByDate(bookingDate);
        }

        public IEnumerable<Bookings> GetBookingByDepartureCity(string departureCity)
        {
            if (String.IsNullOrEmpty(departureCity))
                throw new ArgumentNullException(String.Format("departureCity can't be empty - {0}", "FlightBookingService"));

            return _flightRepository.GetBookingByDepartureCity(departureCity);
        }

   
        public IEnumerable<Bookings> GetBookingByFlightNumber(string flightNumber)
        {
            if (String.IsNullOrEmpty(flightNumber))
                throw new ArgumentNullException(String.Format("flightNumber can't be empty - {0}", "FlightBookingService"));

            return _flightRepository.GetBookingByFlightNumber(flightNumber);
        }

        public IEnumerable<Bookings> GetBookingByPassengerName(string passengerName)
        {
            if (String.IsNullOrEmpty(passengerName))
                throw new ArgumentNullException(String.Format("passengerName can't be empty - {0}", "FlightBookingService"));

            return _flightRepository.GetBookingByPassengerName(passengerName);
        }

        public IEnumerable<Flight> GetFlightAvailability(DateTime startDate, DateTime endDate, int noOfPassengers)
        {
            if (startDate == null) 
                throw new ArgumentNullException(String.Format("startDate can't be empty - {0}", "FlightBookingService"));
           
            if (endDate == null)
                throw new ArgumentNullException(String.Format("endDate can't be empty - {0}", "FlightBookingService"));

            if (noOfPassengers <= 0)
                throw new ArgumentException(String.Format("noOfPassengers must be greater than 0 - {0}", "FlightBookingService"));

            return _flightRepository.GetFlightAvailability(startDate, endDate, noOfPassengers);
        }

        public void MakeBooking(Bookings bookingDetails)
        {
            if (bookingDetails == null)
                throw new ArgumentNullException(String.Format("bookingDetails can't be empty - {0}", "FlightBookingService"));

            var flightInfo = GetAllFlights().Where(f => f.FlightNo.Equals(bookingDetails.FlightNumber, StringComparison.CurrentCultureIgnoreCase)).FirstOrDefault();

            if (flightInfo == null)
                throw new ArgumentException("Flight number is not found");

            _flightRepository.MakeBooking(bookingDetails);
        }
    }
}
